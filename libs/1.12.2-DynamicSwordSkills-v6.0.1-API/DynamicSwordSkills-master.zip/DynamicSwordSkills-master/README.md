DynamicSwordSkills
==================

Mod for those who just want the combat skills from ZSS and none of the mobs, items, world gen, etc.

In addition, there are 'skill' items which grant the user use of a skill, even if the user does not know the skill - these can be found scattered throughout the land.

Mod page on Minecraft Forums: http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1294232
Mod page on Planet Minecraft: http://www.planetminecraft.com/mod/172164-dynamic-sword-skills/
